$ErrorActionPreference = 'SilentlyContinue'
$desktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Attendly.lnk'
$startMenuShortcut = Join-Path (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs') 'Attendly.lnk'

Remove-Item -LiteralPath $desktopShortcut -Force
Remove-Item -LiteralPath $startMenuShortcut -Force
