param(
    [Parameter(Mandatory = $true)]
    [string]$InstallPath
)

$ErrorActionPreference = 'Stop'
$desktop = [Environment]::GetFolderPath('Desktop')
$programs = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs'
$launcher = Join-Path $InstallPath 'Attendly Launcher.vbs'
$icon = Join-Path $InstallPath 'attendly.ico'
$wscript = Join-Path $env:WINDIR 'System32\wscript.exe'
$shortcutPaths = @(
    (Join-Path $desktop 'Attendly.lnk'),
    (Join-Path $programs 'Attendly.lnk')
)

$shell = New-Object -ComObject WScript.Shell
foreach ($shortcutPath in $shortcutPaths) {
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $wscript
    $shortcut.Arguments = '"' + $launcher + '"'
    $shortcut.WorkingDirectory = $InstallPath
    $shortcut.IconLocation = $icon + ',0'
    $shortcut.Description = 'Attendly Offline Attendance System'
    $shortcut.Save()
}
