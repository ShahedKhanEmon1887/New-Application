Option Explicit

Dim fileSystem, shell, appFolder, indexFile, appUrl
Dim edgeCandidates, edgePath, candidate

Set fileSystem = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

appFolder = fileSystem.GetParentFolderName(WScript.ScriptFullName)
indexFile = fileSystem.BuildPath(appFolder, "index.html")

If Not fileSystem.FileExists(indexFile) Then
    MsgBox "Attendly could not find index.html in:" & vbCrLf & appFolder, vbCritical, "Attendly"
    WScript.Quit 1
End If

appUrl = "file:///" & Replace(indexFile, "\", "/")
edgeCandidates = Array( _
    shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"), _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Microsoft\Edge\Application\msedge.exe") _
)

edgePath = ""
For Each candidate In edgeCandidates
    If fileSystem.FileExists(candidate) Then
        edgePath = candidate
        Exit For
    End If
Next

If edgePath <> "" Then
    shell.Run Chr(34) & edgePath & Chr(34) & " --app=" & Chr(34) & appUrl & Chr(34) & " --start-maximized", 1, False
Else
    shell.Run Chr(34) & indexFile & Chr(34), 1, False
End If
