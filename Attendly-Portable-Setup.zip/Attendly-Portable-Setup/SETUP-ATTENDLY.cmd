@echo off
setlocal EnableExtensions
title Attendly Offline - Setup
color 0B

set "SOURCE_DIR=%~dp0Attendly-App"
set "INSTALL_DIR=%LOCALAPPDATA%\Attendly"

echo ==========================================
echo          ATTENDLY OFFLINE SETUP
echo ==========================================
echo.

if not exist "%SOURCE_DIR%\index.html" (
    echo ERROR: The Attendly-App folder is missing or incomplete.
    echo Extract the entire ZIP before running this setup.
    echo.
    pause
    exit /b 1
)

echo Installing Attendly for the current Windows user...
echo Location: %INSTALL_DIR%
echo.

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
xcopy "%SOURCE_DIR%\*" "%INSTALL_DIR%\" /E /I /Y /Q >nul
if errorlevel 1 goto copy_failed

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer\Create-Shortcuts.ps1" -InstallPath "%INSTALL_DIR%"
if errorlevel 1 goto shortcut_failed

echo Installation completed successfully.
echo.
echo A shortcut named Attendly is now on your Desktop
echo and in the Windows Start menu.
echo.
echo Attendly will open now.
start "" "%SystemRoot%\System32\wscript.exe" "%INSTALL_DIR%\Attendly Launcher.vbs"
echo.
pause
exit /b 0

:copy_failed
echo ERROR: Windows could not copy the Attendly application files.
echo Make sure your user account can write to Local AppData.
echo.
pause
exit /b 1

:shortcut_failed
echo Attendly was copied successfully, but Windows could not create shortcuts.
echo You can still run it from:
echo %INSTALL_DIR%\Attendly Launcher.vbs
echo.
pause
exit /b 1
