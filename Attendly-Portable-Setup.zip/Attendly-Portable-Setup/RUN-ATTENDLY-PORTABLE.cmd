@echo off
setlocal EnableExtensions
set "LAUNCHER=%~dp0Attendly-App\Attendly Launcher.vbs"

if not exist "%LAUNCHER%" (
    echo Attendly cannot start because its application files are missing.
    echo Keep RUN-ATTENDLY-PORTABLE.cmd beside the Attendly-App folder.
    pause
    exit /b 1
)

start "" "%SystemRoot%\System32\wscript.exe" "%LAUNCHER%"
exit /b 0
