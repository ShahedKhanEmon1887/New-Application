ATTENDLY OFFLINE - PORTABLE AND SETUP PACKAGE
==============================================

SYSTEM REQUIREMENTS
-------------------
- Windows 10 or Windows 11
- Microsoft Edge or another modern web browser
- No internet connection
- No XAMPP, database, Node.js, Android SDK, Gradle or VS Code

OPTION 1 - INSTALL ATTENDLY (RECOMMENDED)
-----------------------------------------
1. Right-click the downloaded ZIP and choose Extract All.
2. Open the extracted Attendly-Portable-Setup folder.
3. Double-click SETUP-ATTENDLY.cmd.
4. Wait for the message "Installation completed successfully."
5. Use the Attendly shortcut created on your Desktop.

The installer does not need administrator permission. It installs Attendly in:
%LOCALAPPDATA%\Attendly

OPTION 2 - RUN WITHOUT INSTALLING
---------------------------------
1. Keep every file and folder together.
2. Double-click RUN-ATTENDLY-PORTABLE.cmd.
3. Attendly opens in an app-style Microsoft Edge window. If Edge cannot be
   found, it opens in your default web browser.

DEMO LOGIN
----------
Administrator: admin@attendly.local
Teacher:       teacher@attendly.local
Student:       student@attendly.local
PIN for all:   1234

MOVING ATTENDLY TO ANOTHER COMPUTER
-----------------------------------
The app itself can be copied and run anywhere on Windows. Records are stored
locally by the browser on each computer. To move your records:

1. Log in as Administrator on the old computer.
2. Open Backup & Restore.
3. Click Download backup and copy the JSON file to the new computer.
4. Run or install Attendly on the new computer.
5. Log in as Administrator, open Backup & Restore and choose Restore backup.

IMPORTANT
---------
- Always extract the ZIP before running setup. Do not run it inside the ZIP.
- Do not rename or remove files inside Attendly-App.
- Back up your data before changing computer, browser profile or Windows user.
- This version is completely offline; it does not synchronize between devices.

UNINSTALL
---------
Double-click UNINSTALL-ATTENDLY.cmd and type Y when asked.
