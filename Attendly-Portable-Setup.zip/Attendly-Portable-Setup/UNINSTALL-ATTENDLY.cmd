@echo off
setlocal EnableExtensions
title Attendly Offline - Uninstall
color 0C

set "INSTALL_DIR=%LOCALAPPDATA%\Attendly"
set "ANSWER="

echo ==========================================
echo        ATTENDLY OFFLINE UNINSTALL
echo ==========================================
echo.
echo This removes the installed Attendly app and its shortcuts.
echo It does not delete this portable setup folder.
echo.
set /p "ANSWER=Type Y and press Enter to continue: "

if /I not "%ANSWER%"=="Y" (
    echo Uninstall cancelled.
    pause
    exit /b 0
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer\Remove-Shortcuts.ps1"
if exist "%INSTALL_DIR%" rmdir /S /Q "%INSTALL_DIR%"

echo.
echo Attendly was removed from this Windows user account.
pause
exit /b 0
